---
name: "(English) Feature request"
about: Suggest an idea for this project

---

```console
$ ble summary

<!-- Please include the result of the above command if applicable. -->
```

<!-- You can describe the request in a free way. -->
