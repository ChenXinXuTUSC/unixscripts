# ble/contrib/integration/skim-initialize.bash (C) 2024, akinomyoga

ble-import contrib/integration/fzf.common
ble/contrib/integration:fzf/locate-shell-settings _ble_contrib_skim skim sk || return 1
