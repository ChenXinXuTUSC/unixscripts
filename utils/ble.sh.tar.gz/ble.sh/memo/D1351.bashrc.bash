# bashrc

HISTFILE=A.txt
HISTTIMEFORMAT='[%F %T]  '
#HISTTIMEFORMAT=
#HISTTIMEFORMAT='__ble_time_%s__'
HISTSIZE=
HISTFILESIZE=
shopt -s histappend
shopt -s lithist

#history -n
#history 
